import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Lock, Loader2, AlertTriangle } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import PasswordInput from "@/components/PasswordInput";

export default function ResetPassword() {
  /**
   * Do NOT read the token from the URL.
   *
   * Supabase puts the recovery token in the fragment (#access_token=...), but
   * the client is configured with detectSessionInUrl, so it consumes that
   * fragment and STRIPS IT FROM THE URL before React ever renders. Any check
   * of window.location therefore finds nothing and reports a valid link as
   * invalid — which is exactly what happened here.
   *
   * The reliable signal is the session the client created from that token.
   * We wait for it rather than inspecting the address bar.
   */
  const [status, setStatus] = useState("checking"); // checking | ready | invalid

  useEffect(() => {
    let settled = false;

    const accept = () => {
      if (settled) return;
      settled = true;
      setStatus("ready");
    };

    // Fires when the client finishes parsing the recovery link.
    const { data: sub } = base44.auth.onAuthStateChange?.((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") accept();
    }) ?? { data: null };

    // The event may already have fired before this component mounted, so also
    // check directly for an existing session.
    base44.auth
      .isAuthenticated()
      .then((yes) => {
        if (yes) accept();
      })
      .catch(() => {});

    // Give the client a moment to process the fragment before giving up.
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        setStatus("invalid");
      }
    }, 2500);

    return () => {
      clearTimeout(timer);
      sub?.subscription?.unsubscribe?.();
    };
  }, []);

  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    setLoading(true);
    try {
      // No token is passed: by this point the recovery session already exists,
      // so the reset is simply an update to the signed-in user's password.
      await base44.auth.resetPassword({ newPassword });
      window.location.href = "/login";
    } catch (err) {
      const msg = String(err?.message || err);
      setError(
        /expired|invalid/i.test(msg)
          ? "This reset link has expired. Please request a new one."
          : msg || "Failed to reset password"
      );
    } finally {
      setLoading(false);
    }
  };

  if (status === "checking") {
    return (
      <AuthLayout icon={Lock} title="Checking your link" subtitle="One moment">
        <div className="flex justify-center py-6">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      </AuthLayout>
    );
  }

  if (status === "invalid") {
    return (
      <AuthLayout
        icon={AlertTriangle}
        title="Invalid reset link"
        subtitle="This password reset link is missing or invalid"
        footer={
          <Link to="/forgot-password" className="text-primary font-medium hover:underline">
            Request a new link
          </Link>
        }
      >
        <p className="text-sm text-foreground text-center">
          The link you used appears to be incomplete or has already been used.
          Please request a new password reset email.
        </p>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      icon={Lock}
      title="New password"
      subtitle="Enter your new password below"
    >
      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="password">New Password</Label>
          <PasswordInput
            id="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            autoComplete="new-password"
            autoFocus
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm">Confirm Password</Label>
          <PasswordInput
            id="confirm"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            autoComplete="new-password"
          />
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Resetting...
            </>
          ) : (
            "Reset password"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}